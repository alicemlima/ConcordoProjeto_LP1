#ifndef CHANNEL_VOICE_H
#define CHANNEL_VOICE_H

#include "channel.h"

class Channelvoice : public Channel
{
private:
	Message LastMessage;
public:
	// Channelvoice(string nc);
	// ~Channelvoice();
};

#endif